package com.example.spotifyplaylistapp.model.entity.enums;

public enum Styles {
    POP, ROCK, JAZZ
}
